package uml;

import java.util.ArrayList;

import org.dom4j.Element;

public class MsgFragment {
	String connectorId;
	String sourceId;
	String tragetId;
	String name;
	String sendEvent;
	String fragId;
	String fragInteractionOperator;
	String fragBody;
	String fragId1;
	String fragInteractionOperator1;
	String fragBody1;
	String messageSort;
	
	ArrayList<Element> frag=new ArrayList();
	
	public String getConnectorId() 
	{
		return connectorId;
	}
	public void setConnectorId(String connectorId)
	{
		this.connectorId = connectorId;
	}
	public String getSourceId()
	{
		return sourceId;
	}
	public void setSourceId(String sourceId)
	{
		this.sourceId = sourceId;
	}
	public String getTragetId() 
	{
		return tragetId;
	}
	public void setTragetId(String tragetId) 
	{
		this.tragetId = tragetId;
	}
	public String getName() 
	{
		return name;
	}
	public void setName(String name) 
	{
		this.name = name;
	}
	public String getSendEvent() 
	{
		return sendEvent;
	}
	public void setSendEvent(String sendEvent) 
	{
		this.sendEvent = name;
	}
	public String getMessageSort() 
	{
		return messageSort;
	}
	public void setMessageSort(String messageSort) 
	{
		this.messageSort = messageSort;
	}
	public String getFragId() 
	{
		return fragId;
	}
	public void setFragId(String fragId)
	{
		this.fragId = fragId;
	}
	
	public String getFragInteractionOperator() 
	{
		return fragInteractionOperator;
	}
	public void setFragInteractionOperator(String fragInteractionOperator)
	{
		this.fragInteractionOperator = fragInteractionOperator;
	}
	
	public String getFragBody() 
	{
		return fragBody;
	}
	public void setFragBody(String fragBody)
	{
		this.fragBody = fragBody;
	}
	
	public String getFragId1() 
	{
		return fragId1;
	}
	public void setFragId1(String fragId1)
	{
		this.fragId1 = fragId1;
	}
	
	public String getFragInteractionOperator1() 
	{
		return fragInteractionOperator1;
	}
	public void setFragInteractionOperator1(String fragInteractionOperator1)
	{
		this.fragInteractionOperator1 = fragInteractionOperator1;
	}
	
	public String getFragBody1() 
	{
		return fragBody1;
	}
	public void setFragBody1(String fragBody1)
	{
		this.fragBody1 = fragBody1;
	}
	public ArrayList<Element> getFrag()
	{
		return frag;
	}
	public void setFrag(ArrayList<Element> frag)
	{
		this.frag=frag;
	}
}
