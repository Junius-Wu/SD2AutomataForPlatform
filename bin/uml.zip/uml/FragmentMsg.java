package uml;

import java.util.ArrayList;

import org.dom4j.Element;

public class FragmentMsg {
	String fragType;
	String fragId;
	String fragInteractionOperator;
	String fragBody;
	String fragId1;
	String fragInteractionOperator1;
	String fragBody1;
	
	ArrayList<Element> frag=new ArrayList();
	
	public String getFragType() 
	{
		return fragType;
	}
	public void setFragType(String fragType)
	{
		this.fragType = fragType;
	}
	
	public String getFragId() 
	{
		return fragId;
	}
	public void setFragId(String fragId)
	{
		this.fragId = fragId;
	}
	
	public String getFragInteractionOperator() 
	{
		return fragInteractionOperator;
	}
	public void setFragInteractionOperator(String fragInteractionOperator)
	{
		this.fragInteractionOperator = fragInteractionOperator;
	}
	
	public String getFragBody() 
	{
		return fragBody;
	}
	public void setFragBody(String fragBody)
	{
		this.fragBody = fragBody;
	}
	public String getFragId1() 
	{
		return fragId1;
	}
	public void setFragId1(String fragId1)
	{
		this.fragId1 = fragId1;
	}
	
	public String getFragInteractionOperator1() 
	{
		return fragInteractionOperator1;
	}
	public void setFragInteractionOperator1(String fragInteractionOperator1)
	{
		this.fragInteractionOperator1 = fragInteractionOperator1;
	}
	
	public String getFragBody1() 
	{
		return fragBody1;
	}
	public void setFragBody1(String fragBody1)
	{
		this.fragBody1 = fragBody1;
	}
	public ArrayList<Element> getFrag()
	{
		return frag;
	}
	public void setFrag(ArrayList<Element> frag)
	{
		this.frag=frag;
	}
}
