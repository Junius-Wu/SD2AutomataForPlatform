package uml;

public class State 
{
	String StateId;
	String StateName;
	boolean isSender;
	boolean isReceiver;
	
}
