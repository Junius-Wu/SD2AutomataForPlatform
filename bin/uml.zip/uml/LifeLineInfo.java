package uml;

public class LifeLineInfo 
{
	
	String lifeLineId;
	String lifeLineName;
	
	public void setlifeLineId(String lifeLineId)
	{
		this.lifeLineId=lifeLineId;
	}
	public void setlifeLineName(String lifeLineName)
	{
		this.lifeLineName=lifeLineName;
	}
	public String getlifeLineId()
	{
		return lifeLineId;
	}
	public String getlifeLineName()
	{
		return lifeLineName;
	}
}
