package uml;

import java.awt.geom.Area;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;

import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

import uml.Write;

public class EaToUppaal 
{

	public static void main(String[] args) throws Exception 
	{
		
		ArrayList<LifeLineInfo> mainLifeLines=new ArrayList<LifeLineInfo>();
		ArrayList<MsgFragment> mainMsgFragment=new ArrayList<MsgFragment>();
		ArrayList<FragmentMsg> mainFragmentMsg=new ArrayList<FragmentMsg>();
		ArrayList<UppaalTemPlate> UT=new ArrayList<UppaalTemPlate>();
		
		HashSet<String > template_instantiations=new HashSet<String>();
		
		
		SAXReader reader=new SAXReader();//��ȡ������
	    Document dom= reader.read("1.xml");//����XML��ȡ���������ĵ���dom����
	    Element root=dom.getRootElement();//��ȡ���ڵ�
	    
	    Read uml=new Read();
	    uml.load(root);
	    
	    if(uml.hasNoLifeline() )
	    {
	    	System.exit(0);
	    	System.out.println("û���ҵ������ߣ��˳�");
	    }
	    
	    mainLifeLines=uml.getLifeLines();
	    mainMsgFragment=uml.getUmlMsgFragment();
	    mainFragmentMsg=uml.getUmlFragmentMsg();
	    
	  /*  */
	    
	    int id=0;
	    for(Iterator<LifeLineInfo> mainLifeIterator=mainLifeLines.iterator();mainLifeIterator.hasNext();)
	    {
	    	int q=0;
	    	LifeLineInfo lifeNext=mainLifeIterator.next();
	    	System.out.println(lifeNext.getlifeLineName()+"���Զ�����");
	    	template_instantiations.add(lifeNext.getlifeLineName());
	    	UppaalTemPlate UTtemp=new UppaalTemPlate();
	    	UTtemp.setName(lifeNext.getlifeLineName());
	    	
	    	UppaalLocation ULtemp0=new UppaalLocation();
	    	ULtemp0.setId(id++);
	    	ULtemp0.setName("q"+q++);
	    	ULtemp0.setInit(true);
	    	ArrayList<UppaalLocation> UL=new ArrayList<UppaalLocation>();	
	    	UL.add(ULtemp0);
	    	int lastID=ULtemp0.getId();
	    	int tempID=0;
	    	int firstOptID=0;
	    	int firstLoopID=0;
	    	int firstOutLoopID=0;
	    	int firstAltID=0;
	    	String lastKind=null;
	    	int endOptID=0;
	    	int endLoopID=0;
	    	int endAltID1=0;
	    	int endAltID2=0;
	    	int loop1=0;
	    	String loopString2=null;
	    	String loopString=null;
	    	String lastaltTJ="0";
	    	ArrayList<UppaalTransition> uppaalTransitions=new ArrayList<UppaalTransition>();	
	    	for(Iterator<MsgFragment> mainMsgFragmentIterator=mainMsgFragment.iterator();mainMsgFragmentIterator.hasNext();)
		    { 
	    		MsgFragment sigMsg=mainMsgFragmentIterator.next();
	    		
		    	if(lifeNext.getlifeLineId().equals(sigMsg.getSourceId())||lifeNext.getlifeLineId().equals(sigMsg.getTragetId()))
		    	{
		    		UppaalLocation ULtemp=new UppaalLocation();
			    	UppaalTransition ULtTransition=new UppaalTransition();	
		    		UppaalTransition ULtTransition2=new UppaalTransition();	 
		    		UppaalTransition ULtTransition3=new UppaalTransition();	 
	    		    ULtemp.setId(id++);
	    	        ULtemp.setName("q"+q++);
	                UL.add(ULtemp);
	    			ULtTransition.setKind("synchronisation");
		    		
	    			if(sigMsg.getFragId1()==null)
	    			{
		    			if("break".equals(sigMsg.getFragInteractionOperator()))
			    		{  
		    				System.out.println("break"); 
		    				if(lifeNext.getlifeLineId().equals(sigMsg.getSourceId())&&lastKind!=null)
			    				ULtTransition.setNameText(sigMsg.getName()+"!");
		    				else if(lifeNext.getlifeLineId().equals(sigMsg.getSourceId()))
		    				ULtTransition.setNameText("[break]/"+sigMsg.getFragBody()+"/"+sigMsg.getName()+"!");
		    				     
		    				
			    			else if(lifeNext.getlifeLineId().equals(sigMsg.getTragetId())&&lastKind!=null)
			    				ULtTransition.setNameText(sigMsg.getName()+"?");
			    			else
			    				ULtTransition.setNameText("[break]/"+sigMsg.getFragBody()+"/"+sigMsg.getName()+"?");
		    				ULtTransition.setSourceId(lastID);
				    		ULtTransition.setTargetId(ULtemp.getId());
				    	    uppaalTransitions.add(ULtTransition);
				    	    lastKind=sigMsg.getFragInteractionOperator();
		    			}
			    		else if("opt".equals(sigMsg.getFragInteractionOperator()))
			    		{	
			    			System.out.println("opt");
				    		if(lifeNext.getlifeLineId().equals(sigMsg.getSourceId())&&lastKind!=null)
			    				ULtTransition.setNameText(sigMsg.getName()+"!");
		    				else if(lifeNext.getlifeLineId().equals(sigMsg.getSourceId()))
		    					ULtTransition.setNameText("[opt]/"+sigMsg.getFragBody()+"/"+sigMsg.getName()+"!");
			    			else if(lifeNext.getlifeLineId().equals(sigMsg.getTragetId())&&lastKind!=null)
			    				ULtTransition.setNameText(sigMsg.getName()+"?");
			    			else
			    				ULtTransition.setNameText("[opt]/"+sigMsg.getFragBody()+"/"+sigMsg.getName()+"?");
				    		if(lastKind==null)
				    			firstOptID=lastID;
		    				ULtTransition.setSourceId(lastID);
				    		ULtTransition.setTargetId(ULtemp.getId());
				    	    uppaalTransitions.add(ULtTransition);
				    	    lastKind=sigMsg.getFragInteractionOperator();
		    				endOptID=ULtemp.getId();
			    		}
			    		else if("loop".equals(sigMsg.getFragInteractionOperator()))
			    		{
			    			//System.out.println("loop");
			    			if(lifeNext.getlifeLineId().equals(sigMsg.getSourceId())&&lastKind!=null)
			    				ULtTransition.setNameText(sigMsg.getName()+"!");
		    				else if(lifeNext.getlifeLineId().equals(sigMsg.getSourceId()))
		    					{ULtTransition.setNameText("[loop]/"+sigMsg.getFragBody()+"/"+sigMsg.getName()+"!");
		    					loopString2="[loop]/"+sigMsg.getFragBody()+"/"+sigMsg.getName()+"!";
		    					}else if(lifeNext.getlifeLineId().equals(sigMsg.getTragetId())&&lastKind!=null)
			    				ULtTransition.setNameText(sigMsg.getName()+"?");
			    			else
			    				ULtTransition.setNameText("[loop]/"+sigMsg.getFragBody()+"/"+sigMsg.getName()+"?");
		    				if(lastKind==null)
		    				{	
		    					firstOutLoopID=ULtemp.getId()-1;
		    					loop1=1;
		    				}
		    				
		    				if(loop1==1)
		    				{
		    					firstLoopID=ULtemp.getId();
		    					loop1=0;
		    				}
		    				ULtTransition.setSourceId(lastID);
				    		ULtTransition.setTargetId(ULtemp.getId());
				    	    uppaalTransitions.add(ULtTransition);
				    	    lastKind=sigMsg.getFragInteractionOperator();
				    	    
		    				endLoopID=ULtemp.getId();
			    		}
			    	/*	else if("alt".equals(sigMsg.getFragInteractionOperator()))
			    		{
			    			System.out.println("alt");
			    			if(lifeNext.getlifeLineId().equals(sigMsg.getSourceId())&&lastKind!=null)
			    				ULtTransition.setNameText(sigMsg.getName()+"!");
		    				else if(lifeNext.getlifeLineId().equals(sigMsg.getSourceId())&&!lastaltTJ.equals(sigMsg.getFragBody()))
		    					ULtTransition.setNameText("[alt]/"+sigMsg.getFragBody()+"/"+sigMsg.getName()+"!");
			    			else if(lifeNext.getlifeLineId().equals(sigMsg.getTragetId())&&lastKind!=null)
			    				ULtTransition.setNameText(sigMsg.getName()+"?");
			    			else
			    				ULtTransition.setNameText("[alt]/"+sigMsg.getFragBody()+"/"+sigMsg.getName()+"?");
			    			if(lastKind==null)
			    				firstAltID=ULtemp.getId();
				    		if(!lastaltTJ.equals("0")||!sigMsg.getFragBody().equals(lastaltTJ))
				    		{
				    			 ULtTransition.setSourceId(firstAltID);endAltID2=lastID; 
				    		}	
				    		else
				    		{
				    			ULtTransition.setSourceId(lastID);
				    		}
				    		ULtTransition.setTargetId(ULtemp.getId());
				    	    uppaalTransitions.add(ULtTransition);
				    	    lastKind=sigMsg.getFragInteractionOperator();
		    				lastaltTJ=sigMsg.getFragBody();			    	
				    	    endAltID1=ULtemp.getId();
			    		}
			    		else if("par".equals(sigMsg.getFragInteractionOperator()))
			    			System.out.println("par");*/
			    		else 
			    		{	
			    			//System.out.println("a");
			    			if(lifeNext.getlifeLineId().equals(sigMsg.getSourceId()))
			    				ULtTransition.setNameText(sigMsg.getName()+"!");
			    			else 
			    				ULtTransition.setNameText(sigMsg.getName()+"?");
			    			if(lastKind!=null )
			    			{
			    				if(lastKind.equals("break"))			
			    				{
			    					ULtTransition.setSourceId(tempID);
			    					ULtTransition.setTargetId(ULtemp.getId());
			    				}
			    			    if(lastKind.equals("opt"))
			    			    {	
			    			    	 ULtTransition.setSourceId(firstOptID);
			    			    	 ULtTransition.setTargetId(ULtemp.getId());
			    			    	 if(lifeNext.getlifeLineId().equals(sigMsg.getSourceId()))
					    				ULtTransition2.setNameText(sigMsg.getName()+"!");
			    			    	 else 
					    				ULtTransition2.setNameText(sigMsg.getName()+"?");
			    			    	 ULtTransition2.setSourceId(endOptID);
			    			    	 ULtTransition2.setTargetId(ULtemp.getId());
			    			    	 uppaalTransitions.add(ULtTransition2);
			    			    }  
			    			    if(lastKind.equals("alt"))
			    			    { 
			    			    	 ULtTransition.setSourceId(endAltID1);
			    			    	 ULtTransition.setTargetId(ULtemp.getId());
			    			    	 if(lifeNext.getlifeLineId().equals(sigMsg.getSourceId()))
			    			    		 ULtTransition2.setNameText(sigMsg.getName()+"!");
			    			    	 else 
			    			    		 ULtTransition2.setNameText(sigMsg.getName()+"?");
				    			    ULtTransition2.setSourceId(endAltID2);
				    			    ULtTransition2.setSourceId(ULtemp.getId());
				    			    uppaalTransitions.add(ULtTransition2);
			    			    }
			    			    if(lastKind.equals("loop"))
			    			    {
			    			    	 ULtTransition3.setSourceId(endLoopID);
			    			    	 ULtTransition3.setTargetId(firstLoopID);
			    			    	 ULtTransition3.setNameText(loopString2);
			    			    	 ULtTransition3.setKind("synchronisation");
			    			    	 //System.out.println("kkkk"+loopString2);
			    			    	 ULtTransition2.setSourceId(endLoopID);
			    			     
			    			    	 ULtTransition2.setTargetId(ULtemp.getId());
			    			         ULtTransition2.setKind("synchronisation");
			    			    
				    				 ULtTransition2.setNameText(ULtTransition.getNameText());  
				    				// System.out.println(ULtTransition2.getNameText());
				    				 uppaalTransitions.add(ULtTransition3);
				    				 uppaalTransitions.add(ULtTransition2);
				    				 
				    				 ULtTransition.setSourceId(firstOutLoopID);
				    			     ULtTransition.setTargetId(ULtemp.getId());				    			  
			    			     }
			    			}
			    			else
			    			{
				    			ULtTransition.setSourceId(lastID);
					    		ULtTransition.setTargetId(ULtemp.getId());
					    		tempID=ULtemp.getId();
			    			}
				    	    uppaalTransitions.add(ULtTransition);
				    		lastKind=null;
			    		}
			    	}	
    				lastID=ULtemp.getId();
	    			UTtemp.setLocations(UL);	   		
	    			//System.out.println(ULtTransition.getNameText());
		    	}
		   }		    	
           UTtemp.setTransitions(uppaalTransitions);
           UT.add(UTtemp);  
	    }	
	    Write.creatXML("UPPAAL.xml",UT,template_instantiations);
	}
	
}

