package uml;

import java.util.ArrayList;
import java.util.Iterator;

import org.dom4j.Element;

public class Read
{
	ArrayList<LifeLineInfo> umlLifeLines=new ArrayList<LifeLineInfo>();
	ArrayList<SequenceMsg> umlSequenceMsg=new ArrayList<SequenceMsg>();
	ArrayList<ConnectorsMsg> umlConnectors=new ArrayList<ConnectorsMsg>();
	ArrayList<AllSequence> umlAllSequence=new ArrayList<AllSequence>();
	ArrayList<FragmentMsg> umlFragment=new ArrayList<FragmentMsg>();
	ArrayList<FragmentMsg> umlFragmentInner=new ArrayList<FragmentMsg>();
	ArrayList<MsgFragment> umlMsgFragment=new ArrayList<MsgFragment>();
	
	
	public boolean hasNoLifeline()
	{	
		if(umlLifeLines.isEmpty())                             	
			return true;
		else 
			return false;	
	}
	
	public  void load(Element root) throws Exception
	{
		ArrayList<Element> lifeLineList=new ArrayList();
		ArrayList<Element> sequenceMsg=new ArrayList();
		ArrayList<Element> connectorList=new ArrayList();
		ArrayList<Element> fragList=new ArrayList();
		
		lifeLineList.addAll(root.element("Model").element("packagedElement").element("packagedElement").element("ownedBehavior").elements("lifeline"));
		sequenceMsg.addAll(root.element("Model").element("packagedElement").element("packagedElement").element("ownedBehavior").elements("message"));
		connectorList.addAll(root.element("Extension").element("connectors").elements("connector"));
		fragList.addAll(root.element("Model").element("packagedElement").element("packagedElement").element("ownedBehavior").elements("fragment"));
		
		for(Iterator<Element> lifeLineIterator=lifeLineList.iterator();lifeLineIterator.hasNext();)
		{
			Element elLifeLine=lifeLineIterator.next();
			LifeLineInfo lifeLineInfo=new LifeLineInfo();
			lifeLineInfo.setlifeLineId(elLifeLine.attribute("id").getValue());
			lifeLineInfo.setlifeLineName(elLifeLine.attribute("name").getValue());
			umlLifeLines.add(lifeLineInfo);
		}
		
		for(Iterator<Element> sequenceMsgIterator=sequenceMsg.iterator();sequenceMsgIterator.hasNext();)
		{
			Element elSequenceMsg=sequenceMsgIterator.next();
			SequenceMsg umlSequence=new SequenceMsg();
			umlSequence.setSequenceMsgId(elSequenceMsg.attribute("id").getValue());
			umlSequence.setSequenceMsgName(elSequenceMsg.attribute("name").getValue());
			umlSequence.setSequenceMsgSendEvent(elSequenceMsg.attribute("sendEvent").getValue());
			umlSequence.setMessageSort(elSequenceMsg.attribute("messageSort").getValue());
			umlSequenceMsg.add(umlSequence);
		}
		for(Iterator<Element> connectorIterator=connectorList.iterator();connectorIterator.hasNext();)
		{
			Element elConnector=connectorIterator.next();
			ConnectorsMsg connectorsMsg=new ConnectorsMsg();
			connectorsMsg.setConnectorId(elConnector.attribute("idref").getValue());
			connectorsMsg.setSourceId(elConnector.element("source").attribute("idref").getValue());
			connectorsMsg.setTragetId(elConnector.element("target").attribute("idref").getValue());
			connectorsMsg.setName(elConnector.element("properties").attribute("name").getValue());
			umlConnectors.add(connectorsMsg);
		}
		
		for(Iterator<SequenceMsg> umlSequenceMsgIterator=umlSequenceMsg.iterator();umlSequenceMsgIterator.hasNext();)
		{
			SequenceMsg sigSequenceMsg=umlSequenceMsgIterator.next();
			AllSequence allSequence=new AllSequence();
			allSequence.name=sigSequenceMsg.getSequenceMsgName();
			allSequence.connectorId=sigSequenceMsg.getSequenceMsgId();
			allSequence.sendEvent=sigSequenceMsg.getSequenceMsgSendEvent();
			allSequence.messageSort=sigSequenceMsg.getMessageSort();
			
			for(Iterator<ConnectorsMsg> umlConnectorsIterator=umlConnectors.iterator();umlConnectorsIterator.hasNext();)
			{
				ConnectorsMsg sigConnectors=umlConnectorsIterator.next();
				if(sigConnectors.getConnectorId().equals(sigSequenceMsg.getSequenceMsgId()))
				{
					allSequence.sourceId=sigConnectors.getSourceId();
					allSequence.tragetId=sigConnectors.getTragetId();
				}
			}
			umlAllSequence.add(allSequence);
		}
		
		for(Iterator<Element> fragListIterator=fragList.iterator();fragListIterator.hasNext();)
		{
			Element fragSig=fragListIterator.next();
			if(fragSig.attribute("type").getValue().equals("uml:CombinedFragment"))
			{
				if(fragSig.attribute("interactionOperator").getValue().equals("alt"))
				{
					ArrayList<Element> fragAlt=new ArrayList();
					fragAlt.addAll(fragSig.elements("operand"));
					for(Iterator<Element> fragAltIterator=fragAlt.iterator();fragAltIterator.hasNext();)
					{
						ArrayList<Element> al=new ArrayList();
						Element fragAltSig=fragAltIterator.next();
						FragmentMsg fragInfo=new FragmentMsg();
						fragInfo.setFragId(fragSig.attribute("id").getValue());
						fragInfo.setFragInteractionOperator(fragSig.attribute("interactionOperator").getValue());
						fragInfo.setFragBody(fragAltSig.element("guard").element("specification").attribute("body").getValue());
						al.addAll(fragAltSig.elements("fragment"));
						fragInfo.setFrag(al);
						umlFragment.add(fragInfo);
					}	
				}	
				else
				{	
					ArrayList<Element> fragSigList=new ArrayList();
					FragmentMsg fragInfo=new FragmentMsg();
					fragInfo.setFragType(fragSig.attribute("type").getValue());
					fragInfo.setFragId(fragSig.attribute("id").getValue());
					fragInfo.setFragInteractionOperator(fragSig.attribute("interactionOperator").getValue());
					fragInfo.setFragBody(fragSig.element("operand").element("guard").element("specification").attribute("body").getValue());
					fragSigList.addAll(fragSig.element("operand").elements("fragment"));
					for(Iterator<Element> fragSigListIterator=fragSigList.iterator();fragSigListIterator.hasNext();)
					{
						Element fragSigList1=fragSigListIterator.next();
						if(fragSigList1.attribute("type").getValue().equals("uml:CombinedFragment"))
						{
							if(fragSigList1.attribute("interactionOperator").getValue().equals("alt"))
							{
								ArrayList<Element> fragAlt=new ArrayList();
								fragAlt.addAll(fragSigList1.elements("operand"));
								for(Iterator<Element> fragAltIterator=fragAlt.iterator();fragAltIterator.hasNext();)
								{
									ArrayList<Element> al1=new ArrayList();
									Element fragAltSig=fragAltIterator.next();
									FragmentMsg fragInfo1=new FragmentMsg();
									fragInfo1.setFragId1(fragSigList1.attribute("id").getValue());
									fragInfo1.setFragInteractionOperator1(fragSigList1.attribute("interactionOperator").getValue());
									fragInfo1.setFragBody1(fragAltSig.element("guard").element("specification").attribute("body").getValue());
									al1.addAll(fragAltSig.elements("fragment"));
									fragInfo1.setFrag(al1);
									umlFragmentInner.add(fragInfo1);
								}
							}
							else
							{
								ArrayList<Element> al1=new ArrayList();
								FragmentMsg fragInfo1=new FragmentMsg();
								fragInfo1.setFragId1(fragSigList1.attribute("id").getValue());
								fragInfo1.setFragInteractionOperator1(fragSigList1.attribute("interactionOperator").getValue());
								fragInfo1.setFragBody1(fragSigList1.element("operand").element("guard").element("specification").attribute("body").getValue());
								al1.addAll(fragSigList1.element("operand").elements("fragment"));
								fragInfo1.setFrag(al1);
								umlFragmentInner.add(fragInfo1);
							}
						}
						fragInfo.setFrag(fragSigList);
						umlFragment.add(fragInfo);
					}
				}
			}
		}
		
		for(Iterator<AllSequence> umlAllSequenceIterator=umlAllSequence.iterator();umlAllSequenceIterator.hasNext();)
		{
			AllSequence sigAllSequence=umlAllSequenceIterator.next();
			MsgFragment allMsgFragment=new MsgFragment();
			allMsgFragment.setName(sigAllSequence.getName());
			allMsgFragment.setConnectorId(sigAllSequence.getConnectorId());
			allMsgFragment.setSendEvent(sigAllSequence.getSendEvent());
			allMsgFragment.setSourceId(sigAllSequence.getSourceId());
			allMsgFragment.setTragetId(sigAllSequence.getTragetId());
			allMsgFragment.fragId=null;
			allMsgFragment.fragInteractionOperator=null;
			allMsgFragment.fragBody=null;
			allMsgFragment.fragId1=null;
			allMsgFragment.fragInteractionOperator1=null;
			allMsgFragment.fragBody1=null;
			for(Iterator<FragmentMsg> fragIterator=umlFragment.iterator();fragIterator.hasNext();)
			{
				FragmentMsg fragSig=fragIterator.next();
				ArrayList<Element> al=new ArrayList();
				al=fragSig.getFrag();
				for(Iterator<Element> alIterator=al.iterator();alIterator.hasNext();)
				{
					Element alElement=alIterator.next();
					if(alElement.attribute("type").getValue().equals("uml:OccurrenceSpecification"))
					{
						if(sigAllSequence.getSendEvent().equals(alElement.attribute("id").getValue()))
						{
							allMsgFragment.setFragId(fragSig.getFragId());
							allMsgFragment.setFragInteractionOperator(fragSig.getFragInteractionOperator());
							allMsgFragment.setFragBody(fragSig.getFragBody());
						}
					}
					else
					{
						for(Iterator<FragmentMsg> umlFragmentInnerIterator=umlFragmentInner.iterator();umlFragmentInnerIterator.hasNext();)
						{
							FragmentMsg umlFragmentInnerSig=umlFragmentInnerIterator.next();
							ArrayList<Element> alInner=new ArrayList();
							alInner=umlFragmentInnerSig.getFrag();
							for(Iterator<Element> alInnerIterator=alInner.iterator();alInnerIterator.hasNext();)
							{
								Element alElement1=alInnerIterator.next();
								if(sigAllSequence.getSendEvent().equals(alElement1.attribute("id").getValue()))
								{
									allMsgFragment.setFragId(fragSig.getFragId());
									allMsgFragment.setFragInteractionOperator(fragSig.getFragInteractionOperator());
									allMsgFragment.setFragBody(fragSig.getFragBody());
									allMsgFragment.setFragId1(umlFragmentInnerSig.getFragId1());
									allMsgFragment.setFragInteractionOperator1(umlFragmentInnerSig.getFragInteractionOperator1());
									allMsgFragment.setFragBody1(umlFragmentInnerSig.getFragBody1());
								}
							}
						}
					}
				}
			}
			umlMsgFragment.add(allMsgFragment);
		}
		/*System.out.println("��Ϣ�Ƿ������Ƭ���У�"+umlMsgFragment.size());*/
		for(Iterator<MsgFragment> msgFragmentIterator=umlMsgFragment.iterator();msgFragmentIterator.hasNext();)
		{
			MsgFragment sigMsgFragment=msgFragmentIterator.next();
			System.out.println(sigMsgFragment.getName()+"  "+sigMsgFragment.getFragInteractionOperator()+"  "+sigMsgFragment.getFragBody()+"    "+sigMsgFragment.getFragInteractionOperator1()+"  "+sigMsgFragment.getFragBody1());
		}
	}
	
	public ArrayList<LifeLineInfo> getLifeLines()
	{
		return umlLifeLines;
	}
	
	public ArrayList<FragmentMsg> getUmlFragmentMsg()
	{
		return umlFragment;
	}
	public ArrayList<MsgFragment> getUmlMsgFragment()
	{
		return umlMsgFragment;
	}
}
	

