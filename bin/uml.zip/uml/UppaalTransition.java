package uml;

public class UppaalTransition 
{
	int sourceId;
	int targetId;
	String Kind;
	String nameText;
	String nameT=new String();
	String nameS=new String();
	
	public int getSourceId() 
	{
		return sourceId;
	}
	public void setSourceId(int sourceId) 
	{
		this.sourceId = sourceId;
	}
	public int getTargetId() 
	{
		return targetId;
	}
	public void setTargetId(int targetId) 
	{
		this.targetId = targetId;
	}
	public String getKind() 
	{
		return Kind;
	}
	public void setKind(String kind) 
	{
		Kind = kind;
	}
	public String getNameText() 
	{
		return nameText;
	}
	public void setNameText(String nameText) 
	{
		this.nameText = nameText;
	}
	public String getNameS() 
	{
		return nameS;
	}
	public void setNameS(String nameS) 
	{
		this.nameS = nameS;
	}
	public String getNameT() 
	{
		return nameT;
	}
	public void setNameT(String nameT) 
	{
		this.nameT = nameT;
	}
}